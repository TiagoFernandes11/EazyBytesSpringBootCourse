package com.eazybytes.main;

import com.eazybytes.beans.Vehicle;
import com.eazybytes.config.ProjectCongif;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Main {

    public static void main(String[] args) {
        Vehicle vehicle = new Vehicle();
        vehicle.setName("Honda City");
        System.out.println(vehicle.getName());

        var context = new AnnotationConfigApplicationContext(ProjectCongif.class);

        Vehicle veh = context.getBean(Vehicle.class);
        System.out.println(veh.getName());

        System.out.println(context.getBean(String.class));
        System.out.println(context.getBean(Integer.class));
    }
}
